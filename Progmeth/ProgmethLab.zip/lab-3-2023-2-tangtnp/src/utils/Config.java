package utils;

public class Config {
	public static int GhostDoctorLevel = 5;
	public static int MonkLevel = 3;
	public static int MonkeyLevel = 1;
	public static int VillagerLevel = 3;
	public static int GaGhostEnergy = 6;
	public static int HighGhostHp = 10;
	public static int LowGhostHp = 3;
	public static int LowGhostLevel = 1;
	public static int MaBongGhostPower = 4;
	public static int MaBongGhostSpeed = 1;
	public static int PongGhostPower = 1;
	public static int PongGhostLevel = 5;
	public static int PooYaGhostLevel = 10;
	public static int PryGhostPower = 3;
	public static int AmuletLevel = 1;
	public static int BananaLevel = 3;
	public static int SultLevel = 1;
	public static int LeklaiLevel = 5;
}
