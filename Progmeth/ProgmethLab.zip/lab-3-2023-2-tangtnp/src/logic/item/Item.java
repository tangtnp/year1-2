package logic.item;

public abstract class Item {
	//TODO implements here
    public abstract int getLevel();

    public abstract void effect();
}
