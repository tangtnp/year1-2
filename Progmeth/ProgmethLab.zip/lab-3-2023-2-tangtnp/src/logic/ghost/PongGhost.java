package logic.ghost;

import logic.game.GameController;
import utils.Config;

import java.util.ArrayList;

public class PongGhost extends HighGhost{
	//TODO implements here
    private int power ;

    public PongGhost(){
        super() ;
        setPower(Config.PongGhostPower);
    }
    public PongGhost(int power){
        super();
        setPower(power);
    }
    @Override
    public int getLevel(){
        return Config.PongGhostLevel ;
    }
    public String toString(){
        return "PongGhost [HP: " + getHp() + " , Power: " + getPower() + "]";
    }
    @Override
    public void attack(){
        int nowPlayerHP = GameController.getInstance().getHp();
        int atk =getPower() ;
        GameController.getInstance().setHp(nowPlayerHP - atk);
    }

    public void damage(){
        ArrayList<Ghost> ghosts =  GameController.getInstance().getGhosts() ;
        for(int i=0;i<ghosts.size();i++){
            if(ghosts.get(i) instanceof LowGhost){
                ghosts.get(i).decreaseHp(-getPower());
            }
        }
    }


    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }
}
