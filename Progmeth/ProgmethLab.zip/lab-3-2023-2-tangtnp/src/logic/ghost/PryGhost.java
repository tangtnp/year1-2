package logic.ghost;

import logic.game.GameController;
import utils.Config;

public class PryGhost extends LowGhost{
	private int power;
	private int ppt;
	//TODO implements here
	public PryGhost(){
		setPower(Config.PryGhostPower);
		setPpt(0);
	}
	public PryGhost(int power){
		super() ;
		setPower(power);
		setPpt(0);
	}
	public PryGhost(int power,int ppt){
		super() ;
		setPower(power);
		setPpt(ppt);
	}
	public String toString(){
		return "PryGhost [HP: " + getHp() + " , Power: " + getPower() + " , PPT: " + getPpt() + "]";
	}

	@Override
	public void attack(){
		int nowPlayerHP = GameController.getInstance().getHp();
		int atk =getPower()-getPpt() ;
		GameController.getInstance().setHp(nowPlayerHP - atk);
	}


	public int getPower() {
		return power;
	}

	public void setPower(int power) {
		this.power = power;
	}

	public int getPpt() {
		return ppt;
	}

	public void setPpt(int ppt) {
		this.ppt = ppt;
	}
}
