package logic.ghost;

import logic.game.GameController;
import org.ietf.jgss.GSSContext;
import utils.Config;

public class GaGhost extends LowGhost{
	//TODO implements here
	private  int energy ;
    public GaGhost(){
        super() ;
        setEnergy(Config.GaGhostEnergy);
    }
    public GaGhost(int energy){
        super() ;
        setEnergy(energy);
    }
    public String toString(){
        return "GaGhost [HP: " + getHp() + " , Energy: " + getEnergy() + "]";
    }
    @Override
    public void attack() {
        int nowPlayerHP = GameController.getInstance().getHp();
        int atk =getEnergy() ;
        GameController.getInstance().setHp(nowPlayerHP - atk);
    }
    public int getEnergy() {
        return energy;
    }

    public void setEnergy(int energy) {
        this.energy = energy;
    }
}
