package logic.ghost;

import logic.game.GameController;
import utils.Config;

public class MaBongGhost extends LowGhost{
	//TODO implements here
    private int power ;
    private int speed ;

    public MaBongGhost(){
        super() ;
        setPower(Config.MaBongGhostPower);
        setSpeed(Config.MaBongGhostSpeed);
    }
    public MaBongGhost(int power){
        super() ;
        setPower(power);
        setSpeed(Config.MaBongGhostSpeed);
    }
    public MaBongGhost(int power, int speed){
        setPower(power);
        setSpeed(speed);
    }
    public String toString(){
        return "MabongGhost" + " [HP: " + getHp() +" , Power: "+getPower()+" , Speed: "+getSpeed()+"]" ;
    }
    @Override
    public void attack(){
        int nowPlayerHP = GameController.getInstance().getHp();
        int atk =getPower()*getSpeed() ;
        GameController.getInstance().setHp(nowPlayerHP - atk);
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
