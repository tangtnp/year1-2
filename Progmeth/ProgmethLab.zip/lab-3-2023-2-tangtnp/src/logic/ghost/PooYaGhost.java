package logic.ghost;

import logic.game.GameController;
import utils.Config;

import java.util.ArrayList;

public class PooYaGhost extends HighGhost {
    //TODO implements here
    private int power;

    public PooYaGhost(int power) {
        super() ;
        setPower(power);
    }

    public int getLevel(){
        return Config.PooYaGhostLevel ;
    }
    public String toString(){
        return "PooYaGhost" + " [HP: " + getHp() +" , Power: "+getPower()+"]" ;
    }
    @Override
    public void attack(){
        GameController controller = GameController.getInstance() ;
        controller.setHp(controller.getHp()-getPower());
        controller.setScore(controller.getScore()-getPower());
    }
    public void damage() {
        ArrayList<Ghost> ghosts =  GameController.getInstance().getGhosts() ;
        for(int i=0;i<ghosts.size();i++){
            ghosts.get(i).decreaseHp(-getPower());
        }
    }

    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }
}
