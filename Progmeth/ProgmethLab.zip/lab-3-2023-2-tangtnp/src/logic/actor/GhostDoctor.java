package logic.actor;

import logic.game.GameController;
import logic.ghost.Ghost;
import logic.ghost.HighGhost;
import logic.ghost.LowGhost;
import logic.item.Amulet;
import logic.item.Banana;
import logic.item.Item;
import utils.Config;

//TODO implements here
public class GhostDoctor extends Actor {
    // constructor
    public GhostDoctor() {

    }

    // method
    public int getLevel() {
        return Config.GhostDoctorLevel;
    }

    public void attack() {
        GameController controller = GameController.getInstance();
        Ghost target = controller.getGhosts().get(0);
        if (target instanceof LowGhost) {
            target.setHp(0);
        }
    }

    public String toString() {
        return getClass().getSimpleName();
    }
}