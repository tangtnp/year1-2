package logic.actor;

//TODO implements here
public abstract class Actor {
    public abstract int getLevel();

    public abstract void attack();
}
