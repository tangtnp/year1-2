package logic.actor;

import logic.game.GameController;
import logic.ghost.Ghost;
import logic.ghost.HighGhost;
import utils.Config;

//TODO implements here
public class Monk extends Actor {
    public Monk() {

    }
    public int getLevel() {
        return Config.MonkLevel;
    }

    public void attack() {
        GameController controller = GameController.getInstance();
        Ghost target = controller.getGhosts().get(0);
        if (target instanceof HighGhost) {
            target.setHp(target.getHp() - this.getLevel());
        }
    }

    public String toString() {
        return getClass().getSimpleName();
    }
}