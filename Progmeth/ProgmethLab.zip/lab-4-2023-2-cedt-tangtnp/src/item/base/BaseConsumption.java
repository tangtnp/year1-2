package item.base;

public abstract class BaseConsumption extends BaseItem {

    public BaseConsumption(String name) {
        super(name);
    }

}
