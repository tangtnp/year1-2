package item.usage;

public interface Healable {

    int getRecoverPoint();

}
