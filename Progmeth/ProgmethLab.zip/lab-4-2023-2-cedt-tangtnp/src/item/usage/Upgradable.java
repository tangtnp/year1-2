package item.usage;

public interface Upgradable {

    int getLevel();
    void setLevel(int level);
    int getMaxLevel();

}
