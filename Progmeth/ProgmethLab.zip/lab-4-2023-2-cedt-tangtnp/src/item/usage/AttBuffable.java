package item.usage;

public interface AttBuffable {

    int getAttBuff();
    int getBuffTurn();

}
