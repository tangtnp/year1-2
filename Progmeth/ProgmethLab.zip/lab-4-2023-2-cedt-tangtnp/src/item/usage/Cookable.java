package item.usage;

public interface Cookable {

    CookState getCookState();
    void setCookState(CookState cookState);

}
