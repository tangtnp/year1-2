package item.usage;

public enum CookState {
    RAW, COOKED, BURNT
}
