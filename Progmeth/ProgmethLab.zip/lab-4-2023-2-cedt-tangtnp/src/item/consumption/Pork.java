package item.consumption;

import item.base.BaseConsumption;
import item.usage.CookState;
import item.usage.Cookable;
import item.usage.Healable;

import java.util.HashMap;

public class Pork extends BaseConsumption implements Cookable, Healable {
    private CookState cookState;
    private final HashMap<CookState,Integer>RECOVER_PT ;

    public Pork() {
        super("Pork");
        setCookState(CookState.RAW);
        HashMap<CookState,Integer> temp = new HashMap<>() ;
        temp.put(CookState.RAW , 1) ;
        temp.put(CookState.COOKED,2);
        temp.put(CookState.BURNT,0) ;
        RECOVER_PT = temp ;
    }

    @Override
    public int getRecoverPoint() {
        return RECOVER_PT.get(getCookState());
    }

    @Override
    public String toString() {
        String s;
        switch (getCookState()) {
            case RAW -> { s = "Raw"; }
            case COOKED -> { s = "Cooked"; }
            case BURNT -> {s = "Burnt"; }
            default -> {s = "";}
        }
        return s + " " + getName() + " (+" + getRecoverPoint() + " HP)";
    }

    @Override
    public CookState getCookState() {
        return this.cookState;
    }

    @Override
    public void setCookState(CookState cookState) {
        this.cookState = cookState;
    }
}
