package logic.components;

import exception.BadStatusException;

import java.util.ArrayList;

public class Player {
    private String name ;
    private Status status ;
    private int energy ;
    private int money ;
    private ArrayList<Food> foods;
    private ArrayList<Potion> potions;
    private ArrayList<Ore> ores;

    public Player(String name, Status status){
        setName(name);
        setStatus(status);
        if(status.getHp()<1){
            try{
                status.setHp(1);
            } catch (BadStatusException e) {
                throw new RuntimeException(e);
            }
        }
        setEnergy(10);
        setMoney(100);
        setFoods(new ArrayList<>());
        setPotions(new ArrayList<>());
        setOres(new ArrayList<>());

    }

    public Player(String name, Status status, int energy, int money){
        setName(name);
        setStatus(status);
        if(status.getHp()<1){
            try{
                status.setHp(1);
            } catch (BadStatusException e) {
                throw new RuntimeException(e);
            }
        }
        setEnergy(energy);
        setMoney(money);
        setFoods(new ArrayList<>());
        setPotions(new ArrayList<>());
        setOres(new ArrayList<>());
    }
    public boolean buyOre(Ore ore){
        if(money>=ore.getCost()){
            money -= ore.getCost();
            ores.add(ore) ;
            return true ;
        }else{
            return false ;
        }
    }
    public void drinkPotion(int index){
        if(index>=0 && index < potions.size()){
            try{
                status.addStatus(potions.get(index).getIncreasingStatus());
            } catch (BadStatusException e) {
                throw new RuntimeException(e);
            }
            getPotions().remove(index) ;
        }

    }

    public void eatFood(int index){
        if(index>=0 && index < foods.size()){
            energy += foods.get(index).getEnergy() ;
            getFoods().remove(index) ;
        }
    }
    public void sellPotion(int index){
        if(index>=0 && index < potions.size()){
            money += potions.get(index).getPrice() ;
            getPotions().remove(index) ;
        }
    }
    public void sellFood(int index){

        if(index>=0 && index < foods.size()){

            money += foods.get(index).getPrice() ;
            getFoods().remove(index) ;
        }
    }
    public void attack(Monster monster){

        int atk = Math.max(0,status.getAttack()-monster.getStatus().getDurability()) ;
        int monHP = Math.max(0,monster.getStatus().getHp()-atk) ;
        try {
            monster.getStatus().setHp(monHP);
        } catch (BadStatusException e) {
            throw new RuntimeException(e);
        }


    }
    public void magicAttack(Monster monster){
        int monHP = Math.max(0,monster.getStatus().getHp()-status.getMagic()) ;
        try {
            monster.getStatus().setHp(monHP);
        } catch (BadStatusException e) {
            throw new RuntimeException(e);
        }
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Potion> getPotions() {
        return potions;
    }

    public void setPotions(ArrayList<Potion> potions) {
        this.potions = potions;
    }

    public void setFoods(ArrayList<Food> foods) {
        this.foods = foods;
    }

    public ArrayList<Food> getFoods() {
        return foods;
    }

    public void setEnergy(int energy) {
        this.energy = Math.max(0,energy);
    }

    public int getEnergy() {
        return energy;
    }

    public ArrayList<Ore> getOres() {
        return ores;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = Math.max(0,money);
    }

    public void setOres(ArrayList<Ore> ores) {
        this.ores = ores;
    }
}
