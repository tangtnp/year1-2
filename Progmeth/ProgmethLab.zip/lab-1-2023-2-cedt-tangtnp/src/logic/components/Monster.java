package logic.components;

import exception.BadStatusException;

public class Monster {
    private String name ;
    private Status status ;
    private Food food;
    private Potion potion;

    public Monster(String name, Status status){
        setName(name);
        setFood(null);
        setPotion(null);
        setStatus(status);
        if(status.getHp()<1){
            try {
                status.setHp(1);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }


    }
    public void attack(Player player){
        int atk = Math.max(0,status.getAttack()-player.getStatus().getDurability()) ;
        int monHP = Math.max(0,player.getStatus().getHp()-atk) ;
        try {
            player.getStatus().setHp(monHP);
        } catch (BadStatusException e) {
            throw new RuntimeException(e);
        }
    }
    public void magicAttack(Player player){
        int monHP = Math.max(0,player.getStatus().getHp()-status.getMagic()) ;
        try {
            player.getStatus().setHp(monHP);
        } catch (BadStatusException e) {
            throw new RuntimeException(e);
        }
    }

    public String getName() {
        return name;
    }

    public Food getFood() {
        return food;
    }

    public Potion getPotion() {
        return potion;
    }

    public Status getStatus() {
        return status;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setFood(Food food) {
        this.food = food;
    }

    public void setPotion(Potion potion) {
        this.potion = potion;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
