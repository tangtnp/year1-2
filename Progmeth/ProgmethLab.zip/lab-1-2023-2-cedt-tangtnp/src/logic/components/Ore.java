package logic.components;

import java.util.Objects;

public class Ore {
    private String name ;
    private int cost ;

    public Ore(String name ,int cost){
        if(cost<1) cost=1;
        setName(name);
        setCost(cost);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ore ore = (Ore) o;
        return getCost() == ore.getCost() && Objects.equals(getName(), ore.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getCost());
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCost(int cost) {
        this.cost = Math.max(1,cost);
    }

    public String getName() {
        return name;
    }

    public int getCost() {
        return cost;
    }
}
