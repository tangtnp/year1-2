package monkey;

import test.grader.MuscleMonkeyTest;

public class BaseMonkey {
    private int maxHp ;
    private int hp ;
    private int atk ;
    private int def ;

    public BaseMonkey(){
        setMaxHp(30);
        setHp(maxHp);
        setAtk(20);
        setDef(5);
    }
    public BaseMonkey(int maxHp,int atk,int def){
        setMaxHp(maxHp);
        setHp(maxHp);
        setAtk(atk);
        setDef(def);
    }
    public void attack(BaseMonkey m){
        int overallATK = Math.max(0,getAtk()-m.getDef()) ;
        m.setHp(Math.max(0,m.getHp()-overallATK));
    }
    public String getType(){
        return this.getClass().getSimpleName();
    }

    @Override
    public String toString() {
        return "BaseMonkey{" +
                "maxHP=" + maxHp +
                ", hp=" + hp +
                ", atk=" + atk +
                ", def=" + def +
                '}';
    }

    public int getMaxHp() {
        return maxHp;
    }

    public void setMaxHp(int maxHP) {
        this.maxHp = Math.max(0,maxHP);
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        if(hp>maxHp){
            hp=maxHp;
        }
        else if (hp<0) {
            hp=0;
        }
        this.hp = hp;
    }

    public int getAtk() {
        return atk;
    }

    public void setAtk(int atk) {
        this.atk = Math.max(0,atk);
    }

    public int getDef() {
        return def;
    }

    public void setDef(int def) {
        this.def = Math.max(0,def);
    }
}
