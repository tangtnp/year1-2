INSERT INTO logs (log_id, log_type, log_date, user_id)
VALUES (nextval('logs_log_id_seq'), 'login', now(), 1);

INSERT INTO logs (log_id, log_type, log_date, user_id)
VALUES (nextval('logs_log_id_seq'), 'logout', now(), 1);
