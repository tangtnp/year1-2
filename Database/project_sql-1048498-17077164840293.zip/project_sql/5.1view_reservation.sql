SELECT reservation.reservation_id, reservation.reservation_start_time, reservation.reservation_end_time, reservation.reservation_type
FROM reservation
WHERE reservation.user_id = '1' AND reservation.reservation_start_time >= '2023-03-14 12:00:00';