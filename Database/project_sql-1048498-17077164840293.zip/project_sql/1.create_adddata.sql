CREATE TABLE users (
 user_id SERIAL PRIMARY KEY,
 user_firstname VARCHAR(100) NOT NULL,
 user_lastname VARCHAR(100) NOT NULL,
 user_email VARCHAR NOT NULL,
 user_telephone INTEGER NOT NULL,
 user_passwords VARCHAR NOT NULL,
 user_type VARCHAR(255) DEFAULT 'non-member'
);

CREATE TABLE employee (
 user_id INTEGER ,
 employee_duty VARCHAR(255) NOT NULL,
 employee_salary INTEGER NOT NULL,
 PRIMARY KEY (user_id),
 FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE members (
 user_id INTEGER ,
 member_issue TIMESTAMP NOT NULL,
 member_expire TIMESTAMP NOT NULL,
 PRIMARY KEY (user_id),
 FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE drink (
 order_number SERIAL NOT NULL,
 menu_id INTEGER NOT NULL, 
 menu_name INTEGER NOT NULL,
 order_price INTEGER NOT NULL,
 order_size VARCHAR(1) NOT NULL,
 order_sweetness VARCHAR(1) NOT NULL,
 order_topping VARCHAR,
 user_id INTEGER,
 PRIMARY KEY (order_number),
 FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE reservation (
 reservation_id SERIAL NOT NULL,
 reservation_start_time TIMESTAMP NOT NULL,
 reservation_end_time TIMESTAMP NOT NULL,
 reservation_type VARCHAR(20) NOT NULL,
 user_id INTEGER,
 PRIMARY KEY (reservation_id),
 FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE reservation_zone(
 reservation_id INTEGER,
 zone_number INTEGER NOT NULL,
 PRIMARY KEY (reservation_id),
 FOREIGN KEY (reservation_id) REFERENCES reservation(reservation_id)
);

CREATE TABLE reservation_event(
 reservation_id INTEGER,
 event_name VARCHAR(255) NOT NULL,
 event_income INTEGER NOT NULL,
 PRIMARY KEY (reservation_id),
 FOREIGN KEY (reservation_id) REFERENCES reservation(reservation_id)
);

CREATE TABLE feedback(
 feedback_id SERIAL NOT NULL,
 feedback_rate INTEGER NOT NULL,
 feedback_comment VARCHAR(255),
 reservation_id INTEGER,
 PRIMARY KEY (feedback_id),
 FOREIGN KEY (reservation_id) REFERENCES reservation(reservation_id)
);

CREATE TABLE logs (
 log_id SERIAL NOT NULL,
 log_type VARCHAR NOT NULL,
 log_date TIMESTAMP NOT NULL,
 user_id INTEGER,
 PRIMARY KEY (log_id),
 FOREIGN KEY (user_id) REFERENCES users(user_id)
);

INSERT INTO users (user_id, user_firstname, user_lastname, user_email, user_telephone, user_passwords)
VALUES (nextval('users_user_id_seq'), 'Adam' , 'Warlock', 'test@test', 0630930231,'password'),
(nextval('users_user_id_seq'), 'Prame' , 'Sudlhor','test@test2', 0630930232 ,'password2'),
(nextval('users_user_id_seq'), 'Lucky' , 'Sumchai', 'test@test3',0630930233 ,'password3'),
(nextval('users_user_id_seq'), 'Pingy' , 'Sudsuay', 'test@test4',0630930234 ,'password4'),
(nextval('users_user_id_seq'), 'Prim' , 'Rose', 'test@test5',0630930235 ,'password5'),
(nextval('users_user_id_seq'), 'Leo' , 'Parit','test@test6', 0630930236 ,'password6');

INSERT INTO reservation (reservation_id, reservation_start_time, reservation_end_time, reservation_type, user_id)
VALUES (nextval('reservation_reservation_id_seq'),'2023-03-12 12:00:00','2023-03-12 14:00:00', 'zone', 1 ),
(nextval('reservation_reservation_id_seq'),'2023-03-13 12:00:00','2023-03-13 14:00:00', 'zone', 1 ),
(nextval('reservation_reservation_id_seq'),'2023-03-14 12:00:00','2023-03-14 14:00:00', 'zone', 1 ),
(nextval('reservation_reservation_id_seq'),'2023-03-15 12:00:00','2023-03-15 14:00:00', 'zone', 1 ),
(nextval('reservation_reservation_id_seq'),'2023-03-12 14:00:00','2023-03-12 16:00:00', 'zone', 2 ),
(nextval('reservation_reservation_id_seq'),'2023-03-13 14:00:00','2023-03-13 16:00:00', 'zone', 3 ),
(nextval('reservation_reservation_id_seq'),'2023-03-14 14:00:00','2023-03-14 16:00:00', 'zone', 2 ),
(nextval('reservation_reservation_id_seq'),'2023-03-15 14:00:00','2023-03-15 16:00:00', 'event', 4 ),
(nextval('reservation_reservation_id_seq'),'2023-03-16 14:00:00','2023-03-16 16:00:00', 'zone', 2 ),
(nextval('reservation_reservation_id_seq'),'2023-03-17 14:00:00','2023-03-17 16:00:00', 'zone', 3 );

INSERT INTO feedback (feedback_id, feedback_rate, feedback_comment, reservation_id)
VALUES (nextval('feedback_feedback_id_seq'), 5 , 'nice', 1 ),
(nextval('feedback_feedback_id_seq'), 5 , 'nice', 2 ),
(nextval('feedback_feedback_id_seq'), 4 , 'nice', 3 ),
(nextval('feedback_feedback_id_seq'), 5 , 'nice', 4 ),
(nextval('feedback_feedback_id_seq'), 1 , 'nice', 5 ),
(nextval('feedback_feedback_id_seq'), 4 , 'nice', 6 ),
(nextval('feedback_feedback_id_seq'), 2 , 'nice', 7 ),
(nextval('feedback_feedback_id_seq'), 4 , 'nice', 8 ),
(nextval('feedback_feedback_id_seq'), 3 , 'nice', 9 ),
(nextval('feedback_feedback_id_seq'), 2 , 'nice', 10 );