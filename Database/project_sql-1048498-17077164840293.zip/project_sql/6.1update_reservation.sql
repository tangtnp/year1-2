UPDATE reservation 
SET reservation_start_time = '2023-03-20 13:00:00', reservation_end_time = '2023-03-20 15:00:00'
WHERE reservation.reservation_id = 1;