DELETE FROM reservation
WHERE reservation_id = 11;